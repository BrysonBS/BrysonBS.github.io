import cn.com.graph.config.UiConfig;

import javax.swing.*;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;

public class TestConfig {

    @org.junit.Test
    public void testConfig(){
        UiConfig uiConfig = new UiConfig(new JFrame());
        uiConfig.setProperties(new HashMap<>());
    }

    @org.junit.Test
    public void testSave(){
        HashMap<String,String> map = new HashMap<>();
        map.put("rows",5+"");
        map.put("cols",5+"");
        map.put("size",5+"");
        map.put("w",5+"");
        map.put("delay",4+"");
        setProperties(map);
    }
    public void setProperties(Map<String,String> map) {
        JFrame frame = new JFrame();
        String path = null;
        try {
            path = UiConfig.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
            path = "E:\\Project\\spath\\out\\artifacts\\spath_jar\\spath - 副本.jar";
        } catch (URISyntaxException e) {
            JOptionPane.showMessageDialog(frame,e);
        }
        try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
             JarFile jarFile = new JarFile(path);
             JarOutputStream jarOutputStream = new JarOutputStream(byteArrayOutputStream)
        ) {
            jarFile.stream().forEach(e -> {
                try {
                    try (InputStream inputStream = jarFile.getInputStream(e)) {
                        jarOutputStream.putNextEntry(new JarEntry(e.getName()));
                        if ("config.properties".equals(e.getName())) {
                            Properties properties = new Properties();
                            properties.load(inputStream);
                            map.keySet().forEach(key -> {
                                if(properties.containsKey(key)) properties.setProperty(key,map.get(key));
                            });
                            properties.store(jarOutputStream, null);
                        }
                        else {
                            byte[] bytes = new byte[1024];
                            int len = -1;
                            while((len = inputStream.read(bytes)) != -1){
                                jarOutputStream.write(bytes,0,len);
                            }
                        }
                    }

                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(frame,ex);
                }
            });
            jarOutputStream.finish();
            byteArrayOutputStream.writeTo(new FileOutputStream(path));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame,e);
        }
    }
}
